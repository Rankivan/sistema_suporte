-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12-Jan-2021 às 22:03
-- Versão do servidor: 10.4.17-MariaDB
-- versão do PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `suporte_denisoft`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `atendimentos_suporte`
--

CREATE TABLE `atendimentos_suporte` (
  `id_atend` int(32) NOT NULL,
  `nome_atend` varchar(40) NOT NULL,
  `empresa_atend` varchar(40) NOT NULL,
  `telefone_atend` varchar(32) NOT NULL,
  `obs_atend` varchar(400) NOT NULL,
  `situacao_atend` varchar(32) NOT NULL,
  `cadastrante_atend` varchar(32) NOT NULL,
  `momento_atend` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `atendimentos_suporte`
--

INSERT INTO `atendimentos_suporte` (`id_atend`, `nome_atend`, `empresa_atend`, `telefone_atend`, `obs_atend`, `situacao_atend`, `cadastrante_atend`, `momento_atend`) VALUES
(1, 'Teste', 'Empresa Teste', '33122564', 'Não ocorreu nada', 'Resolvido', '1 - ivanrank', '2021-01-12'),
(2, 'Teste', 'Empresa Teste', '33122564', 'não ocorreu nada', 'Resolvido', '1 - ivanrank', '2021-01-12');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `atendimentos_suporte`
--
ALTER TABLE `atendimentos_suporte`
  ADD PRIMARY KEY (`id_atend`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `atendimentos_suporte`
--
ALTER TABLE `atendimentos_suporte`
  MODIFY `id_atend` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
