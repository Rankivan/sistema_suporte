
<?php

 $msg_cadastro_atend =  isset ($_GET ['msg_cadastro_atend']) ? $_GET ['msg_cadastro_atend']: 0 ;

?>







<!--#######################################__HOME__########################################-->

  <div id="eventos_diversos_js">
  <!--___________-->

 <div style="padding: 10px;">
   <div class="row">
     <div class="col-sm-6">
       <div class="card">
        <h5 class="card-header"> Atender </h5>
        <a href="#" style="color: black" type="button"data-toggle="modal" data-target="#form_atendimento"> <div class="card-body">
          
          <p class="card-text">Realize um novo atendimento</p>
          <img src="imagens/conteudo/suporte_2.png" style="width: 40px ; height: 40px ;">
        </div></a>
      </div>
    </div>
    
    <div class="col-sm-6">
     <div class="card">
      <h5 class="card-header"> Pesquise por atendimento </h5>
      <div class="card-body">     
       <form method="post">
        <div class="input-group mb-2">
          <div class="input-group-prepend">
           <div class="input-group-text"> 
              <button  type="submit" name=""> <img src="imagens/conteudo/procurar.png" style="width: 40px ; height: 40px ;" ></button></div>
         </div>
         <input  name="buscar_atendimento" style="height: 70px;" type="text" class="form-control" placeholder="Pesquisar">
       </div>
      </form>
     </div>
   </div>
 </div>

</div> <br>

<div>
 <h5> Selecionar status </h5>
</div>
<div class="btn-group">
  <form method="post">
    <button type="submit"  name="">Pendentes  <img src="imagens/conteudo/pendente.png" style="width: 30px ; height: 30px ;" ></button>
    <input type="hidden" name="buscar_abertos" value="Em aberto">
  </form>

  <form method="post">
    <button type="submit" name="">Resolvidos  <img src="imagens/conteudo/finalizada.png" style="width: 30px ; height: 30px ;" ></button>
    <input type="hidden" name="buscar_resolvidos" value="Resolvido">
  </form>

  <form method="post">
    <button type="submit" name="">Encaminhadas  <img src="imagens/conteudo/encaminhada.png" style="width: 30px ; height: 30px ;" ></button><input type="hidden" name=" buscar_Encaminhados" value="Encaminhado">
  </form>

  <form method="post">
    <button type="submit" name="">Todos <img src="imagens/conteudo/todos.png" style="width: 30px ; height: 30px ;" ></button><input type="hidden" name=" buscar_atendimento" value="">
  </form>




  <form method="post">
  <button style="background-color: #0aae1a; color: white">Agenda <img src="imagens/conteudo/caderno.png" style="width: 30px ; height: 30px ;" ></button>
  </form>

</div><br><br>


 <!--####################################_MENSAGENS DE ERRO_######################################-->



<!--_________________________________________________________________________________________-->

  <!--#######################################__TABELA__########################################-->
  <div class=" table table-responsive" >
    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">N°</th>
          <th scope="col">Nome</th>
          <th scope="col">Empresa</th>
          <th scope="col">Telefone</th>
          <th scope="col">Situação</th>
          <th scope="col">Data</th>
          <th scope="col"> Visualizar </th>

        </tr>
      </thead>
      <tbody>




 <?php         @$buscar_atendimento = '%'.$_POST['buscar_atendimento'].'%'; // Busca aproximada usando % com operador LIKE
               @$buscar_abertos = '%'.$_POST['buscar_abertos'].'%';
               @$buscar_resolvidos = '%'.$_POST['buscar_resolvidos'].'%';
               @$buscar_Encaminhados = '%'.$_POST['buscar_Encaminhados'].'%';


                  //_____________________________PAGINAÇÂO________________________________

                //Arquivo que criará o sistema de páginação do projeto
                //Envio do número da página via GET
                $pagina_atual_atend = filter_input(INPUT_GET,'pagina_atend', FILTER_SANITIZE_NUMBER_INT); 
                //Se ela for vazia será a página 1, senão é igual ao número via GET
                $pagina_atend = (!empty($pagina_atual_atend)) ? $pagina_atual_atend : 1;
                //Definir número de páginas por número de registros
                $quant_de_resultado_por_pag_atend = 5;
                //Cálculo para o início da visualização
                $inicio_list_atend = ($quant_de_resultado_por_pag_atend * $pagina_atend) - $quant_de_resultado_por_pag_atend;


              //#############################################################################################

               if (isset ($_POST['buscar_abertos']) != '') {

                $consulta=1;

                $consulta_tab_atend = $pdo->prepare("SELECT * from atendimentos_suporte where situacao_atend LIKE :situacao_atend limit $inicio_list_atend, $quant_de_resultado_por_pag_atend"); 
                $consulta_tab_atend->bindValue(":situacao_atend",$buscar_abertos);
                $consulta_tab_atend->execute();

                # code...
              }

               if (isset ($_POST['buscar_resolvidos']) != '') {

                 $consulta=1;

                $consulta_tab_atend = $pdo->prepare("SELECT * from atendimentos_suporte  where situacao_atend LIKE :situacao_atend limit $inicio_list_atend, $quant_de_resultado_por_pag_atend"); 
                $consulta_tab_atend->bindValue(":situacao_atend",$buscar_resolvidos);
                $consulta_tab_atend->execute();
                # code...
              }

               if (isset ($_POST['buscar_Encaminhados']) != '') {

                 $consulta=1;

                $consulta_tab_atend = $pdo->prepare("SELECT * from atendimentos_suporte where situacao_atend LIKE :situacao_atend limit $inicio_list_atend, $quant_de_resultado_por_pag_atend"); 
                $consulta_tab_atend->bindValue(":situacao_atend",$buscar_Encaminhados);
                $consulta_tab_atend->execute();
                # code...

              }

          

              //##################################################################################
            
               if (isset ($_POST['buscar_atendimento'])  != '') {
                $consulta_tab_atend = $pdo->prepare("SELECT * from atendimentos_suporte where nome_atend LIKE :nome_atend limit $inicio_list_atend, $quant_de_resultado_por_pag_atend"); 
                $consulta_tab_atend->bindValue(":nome_atend",$buscar_atendimento);
                $consulta_tab_atend->execute();
                # code...
              }


              if (isset ($_POST['buscar_atendimento']) == '' && @$consulta != 1){

            
                //Comando de consulta no banco de dados
                $consulta_tab_atend = $pdo->query("SELECT * from atendimentos_suporte limit $inicio_list_atend, $quant_de_resultado_por_pag_atend");
              }






                $dados_tab_atend = $consulta_tab_atend->fetchAll(PDO::FETCH_ASSOC);
              //Este código conta e repassa as linhas da tabela "usuarios"
              //É um cópigo padrão da estrutura "PDO"
              for ($i=0; $i < count($dados_tab_atend); $i++){
              foreach ($dados_tab_atend[$i] as $key => $value) {
                  //echo $key."-".$value."<br>"; //Apresenta todos os valores das colunas
                  # code...
                }
                //echo $dados[$i]['nome']."<br><br>";
                $id_atend              = $dados_tab_atend[$i]['id_atend'];
                $nome_atend            = $dados_tab_atend[$i]['nome_atend'];
                $empresa_atend         = $dados_tab_atend[$i]['empresa_atend'];
                $telefone_atend        = $dados_tab_atend[$i]['telefone_atend'];
                $obs_atend             = $dados_tab_atend[$i]['obs_atend'];
                $situacao_atend        = $dados_tab_atend[$i]['situacao_atend'];
                $cadastrante_atend     = $dados_tab_atend[$i]['cadastrante_atend'];
                $momento_atend         = $dados_tab_atend[$i]['momento_atend'];
              

                //$linhas = count($dados);//conta quantos registros  por página
    
                  ?>
              <tr>
                <th scope="row"><?php echo utf8_encode($id_atend); ?></th>
                  <td><?php echo utf8_encode($nome_atend); ?></td>
                  <td><?php echo utf8_encode($empresa_atend); ?></td>   
                  <td><?php echo utf8_encode($telefone_atend); ?></td>
                  <td><?php echo utf8_encode($situacao_atend); ?></td>
                  <td><?php echo utf8_encode($momento_atend); ?></td>
                <td>
                  <a href="index.php?funcao=editar_atend&id_atend=<?php echo $id_atend ?>"><img src="imagens/conteudo/olho.png" style="width: 20px ; height: 20px "></a>

                </td>
              </tr>

            <?php }  ?>

        </tbody>
      </table>
    </div>


                <?php   $data_base_atend = new db ();
                 $link_atend = $data_base_atend->conecta_mysqli(); 

                //Iniciando a paginação e contando os usuários do banco de daodos
                  //Somando a quantidade de registros no bd
                  $result_listagem_atend = "SELECT count(id_atend) as resultado_atend FROM atendimentos_suporte"; 
                  $resultado_qtd_rgist_atend = mysqli_query($link_atend,$result_listagem_atend);
                  $quantidade_total_rgist_atend = mysqli_fetch_assoc($resultado_qtd_rgist_atend);

                //Quantidade de páginas que serão apresentadas nos links
                  $quantidade_paginas_atend = ceil($quantidade_total_rgist_atend['resultado_atend'] / $quant_de_resultado_por_pag_atend);
                //Limitar o número do link de paginação
                  $limite_links_maximo_atend = 2;

                 ?>




     <?php  /*Comando php para puxar os dados referente ao id
       e executar a edição.*/

     
    if(isset($_GET['funcao'])=='editar_atend'){
     $id_atend_edit = $_GET['id_atend']; //Passagem de dados via URL por meio GET
  
       //Recuperar dados do usuario a ser editado

      $resultado_consulta_atend = $pdo->query ("select * from atendimentos_suporte where id_atend = '$id_atend_edit'");
       $dados_atend_edit = $resultado_consulta_atend->fetchAll(PDO::FETCH_ASSOC);

       $id_atend          = $dados_atend_edit[0]['id_atend'];
       $nome_atend        = $dados_atend_edit[0]['nome_atend'];
       $empresa_atend     = $dados_atend_edit[0]['empresa_atend'];
       $telefone_atend    = $dados_atend_edit[0]['telefone_atend'];
       $obs_atend         = $dados_atend_edit[0]['obs_atend'];
       $situacao_atend    = $dados_atend_edit[0]['situacao_atend'];
       $cadastrante_atend = $dados_atend_edit[0]['cadastrante_atend'];
       $momento_atend     = $dados_atend_edit[0]['momento_atend'];
      


   /*
    $objDb = new db ();
    $link =  $objDb->conecta_mysqli();

    $id = filter_input(INPUT_GET,'id',FILTER_SANITIZE_NUMBER_INT);

    $result_rato = "SELECT * FROM bd_rato WHERE id = '$id'";
    $resultado_rato = mysqli_query ($link,$result_rato);
    $row_rato = mysqli_fetch_assoc($resultado_rato);*/
  
?>

    <script type="text/javascript">


       $(document).ready(function(){ //Abrir a modal pelo JS
        $("#modal_editar_atend").modal();
      });
   </script>
<?php }?>



















<div align="center">

 <?php
          echo "<a class='btn btn-secondary' href='index.php?pagina_atend=1'>Primeira</a> ";//Primeira página
          for ($pagina_anterior_atend = $pagina_atend -  $limite_links_maximo_atend; $pagina_anterior_atend <= $pagina_atend-1 ; $pagina_anterior_atend ++  ) { 

            if ($pagina_anterior_atend >= 1 ) {
              echo "<a class='btn btn-primary' href='index.php?pagina_atend=$pagina_anterior_atend'>$pagina_anterior_atend</a> ";
                } //Conta uma página para trás e para frente
              }
          echo "<a class='btn btn-danger' href='index.php?pagina_atend=$pagina_atend'> $pagina_atend</a> ";//Página atual

          for ($pagina_posterior_atend = $pagina_atend+ 1; $pagina_posterior_atend <= $pagina_atend + $limite_links_maximo_atend ; $pagina_posterior_atend ++  ) { 

            if ($pagina_posterior_atend <= $quantidade_paginas_atend ) {
              echo "<a class='btn btn-primary' href='index.php?pagina_atend=$pagina_posterior_atend'>$pagina_posterior_atend</a> ";
                } 
              }

          echo "<a class='btn btn-secondary' href='index.php?pagina_atend=$quantidade_paginas_atend'>Última</a> ";//ultima página
          ?>
<hr>
 <h5>Total de usuários = <y><?php echo $quantidade_total_rgist_atend['resultado_atend']; ?></h5></y>
</div>





</div>


<?php include ($modais_atend); ?>
   