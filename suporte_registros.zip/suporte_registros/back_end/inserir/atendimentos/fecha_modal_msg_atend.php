<?php 
   
   include_once ("../../conexao_bd.php");
   @session_start();

 $resultado_registro_atend = 1;
 
         if($resultado_registro_atend==1){

              header("location: ../../../index.php");

           // header('location:../../tela_login.php?erro=1');//MENSAGEM DE ERRO


         }




  ?>         