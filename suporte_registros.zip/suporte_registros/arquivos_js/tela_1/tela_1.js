


$("#btn_salvar_atend").hide();


function btn_edita_atend (){

alert();

$("#btn_salvar_atend").hide();


}