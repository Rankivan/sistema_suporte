


<div>

                  <div class="form-row">
                    <div class="form-group col-md-4">
                      <label >Nome </label>
                      <input value="<?php echo utf8_encode ($nome_atend);  ?>" name="nome_atend_edit" type="text" class="form-control" required="" placeholder="Digite um nome" disabled>
                    </div>
                    <div class="form-group col-md-4">
                      <label >Empresa</label>

                      <input value="<?php echo utf8_encode ($empresa_atend);  ?>" name="empresa_atend_edit" type="text" class="form-control" required="" placeholder="Digite a empresa" disabled>
                 
                    </div>



                   <div class="form-group col-md-4">
                      <label >Telefone</label>

                      <input value="<?php echo utf8_encode ($telefone_atend);  ?>" name="telefone_atend_edit" type="text" class="form-control" required="" placeholder="Telefone para contato" disabled >
                 
                    </div>
                  

                   <div class="form-group col-md-4">
                      <label >Observações</label>

                      <textarea  name="obs_atend_edit"  type="text" class="form-control" required="" placeholder="Ocorrencia" disabled><?php echo utf8_encode ($obs_atend); ?></textarea>
                 
                    </div>
                  

                      <div class="form-group col-md-4">
                            <label >Situação</label>
                             <select  name="situacao_atend" class="form-control" required="" id=""  onchange="" disabled >
                         
                              <option value="<?php echo utf8_encode ($situacao_atend);  ?>"> <?php echo utf8_encode ($situacao_atend)  ?></option>
                              <option value="Resolvido">Resolvido</option>
                              <option value="Encaminhado">Encaminhado p/ prog.</option>
                              <option value="Em aberto">Em aberto</option>
                              <option value="Outro">Outro</option>

                            </select>
                      </div>


                     <div class="form-group col-md-4">
                      <label >Data do atendimento</label>

                      <input value="<?php echo utf8_encode ($momento_atend);  ?>" type="text" class="form-control" required="" placeholder="Data do atendimento" disabled>
                 
                    </div>
                  


               </div>

                         <input type="hidden" value="<?php echo utf8_encode ($cadastrante_atend)  ?>" name="cadastrante_atend_edit" disabled >
                
    </div>
