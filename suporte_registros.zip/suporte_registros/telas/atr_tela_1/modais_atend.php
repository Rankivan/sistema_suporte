<!--#######################################__ CADASTRAR __########################################-->

 <form method="post" action="back_end/inserir/atendimentos/inserir_atendimentos.php">
    <div class="modal fade" id="form_atendimento" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable  modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Novo atendimento</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <!--ARRUMAR O BOTÃO POST-->
          <div class="modal-body" >
           
          
            <?php include($form_novo_atend);  ?>
          
         </div>
         <div class="modal-footer">
          <button type="submit" class="btn btn-success">Registrar</button>
           
        </div>
      </div>
    </div>
  </div> 
</form>

<!--################################################-->




<!--#######################################__ EDITAR __########################################-->


    <div class="modal fade" id="modal_editar_atend" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-scrollable  modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Editar atendimento N° &nbsp <h4> <y style="color: #960004"> <?php echo $_GET['id_atend']; ?> </y></h4> </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <!--ARRUMAR O BOTÃO POST-->
          <div class="modal-body" >
           
             <?php  include ($formulario_editar_atendimento);  ?>
         
         </div>
         <div class="modal-footer">

           <form>
            <div>
            <button type="submit" class="btn btn-danger">Excluir <img src="imagens/conteudo/excluir_2.png" style="width: 30px ; height: 30px "></button>
            </div>
          </form>

           <form method="post" action="back_end/inserir/atendimentos/fecha_modal_msg_atend.php">
           <button type="submit" class="btn btn-dark">Fechar <img src="imagens/conteudo/fechar_janela.png" style="width: 30px ; height: 30px "></button>
           </form>
         
         <div id="btn_edita_atend">
          <button  class="btn btn-primary" onclick="btn_edita_atend();">Editar <img src="imagens/conteudo/cadastro.png" style="width: 30px ; height: 30px "></button>
         </div>

     
          <form id="btn_salvar_atend">
           <button type="submit" class="btn btn-success">Salvar <img src="imagens/conteudo/armazena.png" style="width: 30px ; height: 30px "></button>
          </form>
    
          
           
        </div>
      </div>
    </div>
  </div> 


<!--################################################-->











<!--#######################################__ MENSAGEM __########################################-->

              <?php if ($msg_cadastro_atend==1){ ?>
                    <script type="text/javascript">
                      $(document).ready(function(){ //Abrir a modal pelo JS
                      $("#modal_mensagem_cad_atend").modal();
                      });
                    </script>

                <?php }  ?> 

                  <?php if ($msg_cadastro_atend==2){ ?>
                    <script type="text/javascript">
                      $(document).ready(function(){ //Abrir a modal pelo JS
                      $("#modal_mensagem_cad_atend").modal();
                      });
                    </script>

                <?php }  ?>

<!-- Modal -->
<div class="modal fade" id="modal_mensagem_cad_atend" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Retorno</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <?php if ($msg_cadastro_atend==1){ ?>

         <h5 style="color: #00730e"> Atendimento cadastrado com sucesso!!! </h5>


          <?php } ?>

          <?php if ($msg_cadastro_atend==2){ ?>

          <h5  style="color: #960004"> Erro ao cadastrar o atendimento </h5>


          <?php } ?>
        
      </div>
      <div class="modal-footer">
        <form method="post" action="back_end/inserir/atendimentos/fecha_modal_msg_atend.php">

          <button type="submit" class="btn btn-secondary">fechar</button>

        </form>
        
      </div>
    </div>
  </div>
</div>




          